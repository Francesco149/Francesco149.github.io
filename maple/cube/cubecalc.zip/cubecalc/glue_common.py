from common import *

@global_enum
class CalcParam(IntEnum):
  WANTS = auto()
  CUBE = auto()
  TIER = auto()
  CATEGORY = auto()
